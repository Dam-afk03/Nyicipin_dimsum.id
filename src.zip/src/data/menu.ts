import type { ProdukSiap, ProdukFrozen } from '../types'

export const Siap: ProdukSiap[] = [
  {
    id: '1',
    nama: 'Dimsum Goreng Keju',
    lencana: 'Best Seller',
    saus: ['Chili Oil', 'Saus Mentai', 'Saus Bangkok'],
    harga: { 3: 15000, 6: 28000, 9: 40000 },
  },
  {
    id: '2',
    nama: 'Dimsum Ayam Original',
    lencana: 'Favorit Keluarga',
    saus: ['Chili Oil', 'Saus Bangkok'],
    harga: { 3: 12000, 6: 22000, 9: 32000 },
  },
  {
    id: '3',
    nama: 'Dimsum Pedas Jeletot',
    lencana: 'Pedas Nagih',
    saus: ['Chili Oil', 'Ekstra Cabai'],
    harga: { 3: 15000, 6: 28000, 9: 40000 },
  },
]

export const Frozen: ProdukFrozen[] = [
  { ukuran: 3, nama: 'Dimsum Goreng Keju (Frozen)', harga: 14000, lencana: 'Tahan 30 Hari' },
  { ukuran: 6, nama: 'Dimsum Goreng Keju (Frozen)', harga: 26000, lencana: 'Best Seller' },
  { ukuran: 9, nama: 'Dimsum Goreng Keju (Frozen)', harga: 38000, lencana: 'Rame-rame' },
]