import {Navbar, Nav, Container, Button, Badge} from 'react-bootstrap'

interface Props {
    jumlahItem: number
    onKeranjang: () => void
    onBeranda: () => void
}

export default function NavbarToko({jumlahItem, onKeranjang, onBeranda}: Props){
    return (
        <Navbar expand="md" className="border-bottom py-3">
            <Container>
                <Navbar.Brand href="#" className="judul-serif fs-3" onClick={e => { e.preventDefault(); onBeranda()}}>Dimsum.id</Navbar.Brand>
                <Navbar.Toggle aria-controls="menu-utama"/>
                <Navbar.Collapse id="menu-utama">
                <Nav className="mx-auto">
                    <Nav.Link href="#menu">Menu</Nav.Link>
                    <Nav.Link href="#cara-pesan">Cara Pesan</Nav.Link>
                    <Nav.Link href="#tentang">Tentang Kami</Nav.Link>
                    <Nav.Link href="#testimoni">Testimoni</Nav.Link>
                    <Nav.Link href="#kontak">Kontak</Nav.Link>
                </Nav>
                <Button className="btn-hijau rounded-pill" onClick={onKeranjang}>
                    Keranjang<Badge bg="warning" text="dark">{jumlahItem}</Badge>
                </Button>
                </Navbar.Collapse>
      </Container>
    </Navbar>
    )
}