import {Container, Row, Col, Button} from 'react-bootstrap'

export default function Hero(){
    return(
        <Container className="py-5">
            <Row className="align-item-center g-4">
                <Col md={6}>
                <div className="small fe-semibold" style={{color: 'var(merah)'}}>
                    RENYAH DI LUAR, LUMER DI DALAM
                </div>
                <h1 className="judul-serif display-4 my-3">Sekali gigit, langsung jatuh keju</h1>
                <p className="Lead">
                    Dimsum goreng keju yang bikin susah berhenti. Mau hangat sekarang atau nanti?
                </p>
                <Button href="#menu" className="btn-merah rounded-pill px-4 me-2">Pilih Bahagiamu</Button>
                <Button href="#cara" variant="light" className="rounded-pill px-4">Cara Pemesanan</Button> 
                </Col>
                <Col md={6}>
                <div className="foto-semua" style={{aspectRatio: '4/ 3.4', fontSize: '7rem'}}>🧀</div>
                </Col>
            </Row>
        </Container>
    )
}